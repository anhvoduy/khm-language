BUILDING AN API CLIENT WITH WEBCLIENT
Hi. Thanks for watching this course. Here you can find some notes and resources related to the content shown in this module.


Links:
Spring WebFlux documentation for WebClient
https://docs.spring.io/spring/docs/current/spring-framework-reference/web-reactive.html#webflux-client

Sending HTTP requests with Spring WebClient
https://reflectoring.io/spring-webclient/

Spring Boot - How to use WebClient
https://gustavopeiretti.com/spring-boot-how-to-use-webclient/

Spring Boot WebClient Cheat Sheet
https://medium.com/swlh/spring-boot-webclient-cheat-sheet-5be26cfa3e