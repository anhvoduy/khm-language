package com.wiredbraincoffee.productapiannotation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductApiAnnotationApplicationTests {

	@Test
	void contextLoads() {
	}

}
