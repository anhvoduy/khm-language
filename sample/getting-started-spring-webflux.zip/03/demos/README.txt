LEARNING REACTIVE PROGRAMMING WITH REACTOR 
Hi. Thanks for watching this course. Here you can find some notes and resources related to the content shown in this module.


LINKS
Maven Central Repository
http://search.maven.org

Reactive Streams Specification
https://github.com/reactive-streams/reactive-streams-jvm

Reactor Documentation
http://projectreactor.io/docs/core/snapshot/reference/

Reactor Javadoc
http://projectreactor.io/docs/core/release/api/

Appendix A: Which operator do I need?
https://projectreactor.io/docs/core/release/reference/index.html#which-operator

Appendix B: FAQ, Best Practices, and "How do I...?"
https://projectreactor.io/docs/core/release/reference/index.html#faq

Lite Rx API Hands-on
https://github.com/reactor/lite-rx-api-hands-on