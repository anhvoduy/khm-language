INTRODUCING SPRING WEBFLUX
Hi. Thanks for watching this course. Here you can find some notes and resources related to the content shown in this module.


LINKS
Pluralsight Course: Spring Framework: Spring Fundamentals
https://www.pluralsight.com/courses/spring-framework-spring-mvc-fundamentals

Pluralsight Course: Spring Framework: Spring MVC Fundamentals
https://www.pluralsight.com/courses/spring-framework-spring-mvc-fundamentals

Pluralsight Course: Using Lambda Expressions in Java Code
https://www.pluralsight.com/courses/lambda-expressions-java-code

Download JDK:
https://www.oracle.com/java/technologies/javase-downloads.html

Download IntelliJ IDEA:
https://www.jetbrains.com/idea/download/

Reactive Streams website:
http://www.reactive-streams.org/

ReactiveX
http://reactivex.io/languages.html

The Reactive Manifesto
https://www.reactivemanifesto.org/

ReactiveAdapterRegistry Documentation:
https://docs.spring.io/spring-framework/docs/5.3.9/javadoc-api/org/springframework/core/ReactiveAdapterRegistry.html
Or:
https://docs.spring.io/spring-framework/docs/current/javadoc-api/org/springframework/core/ReactiveAdapterRegistry.html

Project Reactor
https://projectreactor.io


To learn more:
Reactive programming vs. Reactive systems
https://www.oreilly.com/ideas/reactive-programming-vs-reactive-systems

Notes on Reactive Programming Part I: The Reactive Landscape
https://spring.io/blog/2016/06/07/notes-on-reactive-programming-part-i-the-reactive-landscape

Java 8: Writing asynchronous code with CompletableFuture
http://www.deadcoderising.com/java8-writing-asynchronous-code-with-completablefuture/

The introduction to Reactive Programming you've been missing
https://gist.github.com/staltz/868e7e9bc2a7b8c1f754
